﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CS440QuotationAppAvila.Quotation
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            Page.MaintainScrollPositionOnPostBack = true;
        }
        protected void bttnCalculate_Click(object sender, EventArgs e)
        {
            //Calculate Dicount Amount
            if(lblCanProgress.Visible)
                lblCanProgress.Visible = false;
            double DiscountAmount = (Convert.ToDouble(txtSalesPrice.Text) * Convert.ToDouble(txtDiscountPercent.Text) / 100);
            lblDiscountAmountUser.Text= (DiscountAmount).ToString("c");
            lblTotalPriceUser.Text =(Convert.ToDouble(txtSalesPrice.Text) - DiscountAmount).ToString("c");
            
          
            //Calculate Total Price
        }

        protected void bttnConfirm_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                if (lblDiscountAmountUser.Text == " " || lblTotalPriceUser.Text == " ")
                {
                    lblCanProgress.Visible = true;
                }
                else
                {
                    Context.Items.Add("SalesPrice", txtSalesPrice.Text);
                    Context.Items.Add("DiscountAmount", lblDiscountAmountUser.Text);
                    Context.Items.Add("TotalPrice", lblTotalPriceUser.Text);
                    Server.Transfer("Confirmation.aspx");
                    lblCanProgress.Visible = false;
                }
            }
        }
    }
}
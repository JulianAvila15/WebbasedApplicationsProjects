﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CS440QuotationAppAvila.Quotation
{
    public partial class Confirmation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            Page.MaintainScrollPositionOnPostBack = true;
            
                if (!IsPostBack)
                {
                    if (Context.Items["SalesPrice"] == null || Context.Items["DiscountAmount"]==null || Context.Items["TotalPrice"]==null)
                    {
                        Server.Transfer("Redirect.aspx");
                    }
                    lblSalesPriceConfirmUser.Text = "$" + Context.Items["SalesPrice"].ToString();
                    lblDiscountAmountConfirmUser.Text = Context.Items["DiscountAmount"].ToString();
                    lblTotalPriceConfirmUser.Text = Context.Items["TotalPrice"].ToString();
                }
            }
        

        protected void bttnConfirm_Click(object sender, EventArgs e)
        {
            Server.Transfer("Default.aspx");
        }

        protected void bttnSend_Click(object sender, EventArgs e)
        {
            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("smtp.sendgrid.com");

                mail.From = new MailAddress("elmcsis1871@gmail.com");
                mail.To.Add(txtEmail.Text);
                mail.Subject = "Quotation";
                mail.Body = "Hello, "+txtName.Text +"\n" +
                            "Regarding your Quotation: \n"
                            +"Your Sales Price: "+lblSalesPriceConfirmUser.Text+"\n"
                            +"Your Discount Amount: "+lblDiscountAmountConfirmUser.Text+"\n"
                            +"Your Total Price: "+lblTotalPriceConfirmUser.Text +"\n";

                SmtpServer.Port = 25;
                SmtpServer.Credentials = new System.Net.NetworkCredential("apikey", "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");
               

                SmtpServer.Send(mail);
                lblMssgBox.Text = "mail Sent";
            }
            catch (Exception ex)
            {
                lblMssgBox.Text ="Failed to send mail";
            }
        }
    }
}
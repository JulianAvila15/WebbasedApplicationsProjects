﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ERM_Web_App.ERMS
{
    public partial class Update : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            Page.MaintainScrollPositionOnPostBack = true;
            txtFirstName.Focus();

            if(!Page.IsPostBack)
            {
                getDetails(Request.QueryString["ID"]);
            }
           
        }

        protected void getDetails(string RecID)
        {
            //setup and create connection to DB

            string strConnection = "Data Source = sql.elmcsis.com; Initial Catalog = ERM_Avila; user ID=e0700532;Password=Elmhurst1871;";
            string SQL = "SELECT * FROM [Registration_table] WHERE [RegistrationID] = '" + RecID + "';";

            //Response.Write("<p>" + SQL + "<p>");

            SqlConnection objConnection = new SqlConnection(strConnection);

            SqlCommand objCommand = new SqlCommand(SQL);

            objCommand.Connection = objConnection;

            objCommand.Connection.Open();

            SqlDataReader objReader = objCommand.ExecuteReader();

            if (objReader.HasRows)
            {
                while (objReader.Read())
                {
                    txtFirstName.Text = objReader["FirstName"].ToString();
                    txtLastName.Text = objReader["LastName"].ToString();
                    txtBadgeName.Text = objReader["BadgeName"].ToString();
                    txtAddress1.Text = objReader["Address1"].ToString();
                    txtAddress2.Text = objReader["Address2"].ToString();
                    txtCity.Text = objReader["City"].ToString();
                    txtState.Text = objReader["State"].ToString();
                    txtZip.Text = objReader["ZipCode"].ToString();


                    RadLunchOptions.SelectedValue = objReader["LunchOptions"].ToString();

                    ChkAudioAid.Checked = (bool)objReader["AudioAid"];
                    ChkVisualAid.Checked = (bool)objReader["VisualAid"];
                    ChkMobileAid.Checked = (bool)objReader["MobileAid"];

                    if (objReader["Rate"].ToString()== "1000.0000")
                    {
                        lstRates.SelectedValue = "Member";
                    }
                    else if(objReader["Rate"].ToString() == "1300.0000")
                    {
                        lstRates.SelectedValue = "Non-Member";
                    }
                    else
                    {
                        lstRates.SelectedValue = "RAUG";
                    }

                    lstRates.SelectedValue = objReader["Rate"].ToString();

                }
            }

            objReader.Close();
            objConnection.Close();

            objReader = null;
            objCommand = null;
            objConnection = null;


        }

        protected bool UpdateRegistration(string RecID)
        {
            try 
            {

                // setup and create the connection to the database
                ADODB.Connection objConnect = new ADODB.Connection();
                ADODB.Recordset objRS = new ADODB.Recordset();

                string strConnection = System.Configuration.ConfigurationManager.AppSettings["ConnectionStringProvider"];
                string SQL = "SELECT * FROM [Registration_table] WHERE [RegistrationID] = '" + RecID +"';";

                // open the connection
                objConnect.Open(strConnection);
                objRS.Open(SQL, objConnect, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic);

                // add registration record

                objRS.Fields["FirstName"].Value = txtFirstName.Text;
                objRS.Fields["LastName"].Value = txtLastName.Text;
                objRS.Fields["BadgeName"].Value = txtBadgeName.Text;

                objRS.Fields["Address1"].Value = txtAddress1.Text;
                objRS.Fields["Address2"].Value = txtAddress2.Text;
                objRS.Fields["City"].Value = txtCity.Text;
                objRS.Fields["State"].Value = txtState.Text;
                objRS.Fields["ZipCode"].Value = txtZip.Text;


                objRS.Fields["LunchOptions"].Value = RadLunchOptions.SelectedValue.ToString();

                if (ChkAudioAid.Checked)
                {
                    objRS.Fields["AudioAid"].Value = 1;
                }

                if (ChkVisualAid.Checked)
                {
                    objRS.Fields["VisualAid"].Value = 1;
                }

                if (ChkMobileAid.Checked)
                {
                    objRS.Fields["MobileAid"].Value = 1;
                }


                if (lstRates.SelectedValue.ToString() == "Member")
                {
                    objRS.Fields["Rate"].Value = 1000;
                }
                else if (lstRates.SelectedValue.ToString() == "Non-Member")
                {
                    objRS.Fields["Rate"].Value = 1300;
                }
                else if (lstRates.SelectedValue.ToString() == "RAUG")
                {
                    objRS.Fields["Rate"].Value = 500;
                }


                objRS.Fields["DateTimeModified"].Value = DateTime.Now;

                objRS.Update();

                objRS.Close();
                objConnect.Close();

                objConnect = null;
                objRS = null;

                return true;
            
            }
            catch
            {
                return false;
            }
        }

        protected bool SaveRegistration(string RecID)
        {
            try
            {
                string connectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"]; ;
                string SQL = "UPDATE Registration_table SET FirstName =@FirstName, LastName = @LastName, BadgeName= @BadgeName, Address1=@Address1, Address2=@Address2, City=@City, State=@State, ZipCode= @ZipCode, LunchOptions = @LunchOptions, Rate = @Rate, AudioAid = @AudioAid, VisualAid = @VisualAid, MobileAid = @MobileAid,  DateTimeModified = @DateTimeModified WHERE RegistrationID = @RegID ";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(SQL, connection);

                    command.Parameters.AddWithValue("@RegID", RecID);

                    command.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                    command.Parameters.AddWithValue("@LastName", txtLastName.Text);
                    command.Parameters.AddWithValue("@BadgeName", txtBadgeName.Text);

                    command.Parameters.AddWithValue("@Address1", txtAddress1.Text);
                    command.Parameters.AddWithValue("@Address2", txtAddress2.Text);
                    command.Parameters.AddWithValue("@City", txtCity.Text);
                    command.Parameters.AddWithValue("@State", txtState.Text);
                    command.Parameters.AddWithValue("@ZipCode", txtZip.Text);

                    command.Parameters.AddWithValue("@AudioAid", (bool)ChkAudioAid.Checked);
                    command.Parameters.AddWithValue("@VisualAid", (bool)ChkVisualAid.Checked);
                    command.Parameters.AddWithValue("@MobileAid", (bool)ChkMobileAid.Checked);

                    command.Parameters.AddWithValue("@LunchOptions", RadLunchOptions.SelectedValue.ToString());


                    if (lstRates.SelectedValue.ToString() == "Member")
                    {
                        command.Parameters.AddWithValue("@Rate","1000.0000");
                    }
                    else if(lstRates.SelectedValue.ToString() == "Non-Member")
                    {

                        command.Parameters.AddWithValue("@Rate","1300.0000");
                    }
                    else if (lstRates.SelectedValue.ToString() == "RAUG")
                    {

                        command.Parameters.AddWithValue("@Rate", "500.0000");
                    }

                    command.Parameters.AddWithValue("@DateTimeModified", DateTime.Now);

                    connection.Open();
                    command.ExecuteNonQuery();
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        protected void bttnSubmit_Click(object sender, EventArgs e)
        {
            if(IsValid)
            {
                if(SaveRegistration(Request.QueryString["ID"]))
                {
                    Server.Transfer("Dashboard.aspx");
                }
                else
                {
                    Server.Transfer("Error.aspx");
                }
            }
        }

        protected void lnkbttnCancel_Click(object sender, EventArgs e)
        {
            Server.Transfer("View.aspx?ID=" + Request.QueryString["ID"]);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ERM_Web_App.ERMS
{
    public partial class View : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //load specific registration record
            
            getDetails(Request.QueryString["ID"]);
        }

        protected void getDetails(string RecID)
        {
            //setup and create connection to DB

            string strConnection = "Data Source = sql.elmcsis.com; Initial Catalog = ERM_Avila; user ID=e0700532;Password=Elmhurst1871;";
            string SQL = "SELECT * FROM [Registration_table] WHERE [RegistrationID]= '" + RecID +"';";

            //Response.Write("<p>" + SQL + "<p>");

            SqlConnection objConnection = new SqlConnection(strConnection);

            SqlCommand objCommand = new SqlCommand(SQL);

            objCommand.Connection = objConnection;

            objCommand.Connection.Open();

            SqlDataReader objReader = objCommand.ExecuteReader();

            if(objReader.HasRows)
            {
                while(objReader.Read())
                {
                    lblFirstName.Text = objReader["FirstName"].ToString();
                    lblLastName.Text = objReader["LastName"].ToString();
                    lblBadgeName.Text = objReader["BadgeName"].ToString();
                    lblAddress1.Text = objReader["Address1"].ToString();
                    lblAddress2.Text = objReader["Address2"].ToString();
                    lblCity.Text = objReader["City"].ToString();
                    lblState.Text = objReader["State"].ToString();
                    lblZip.Text = objReader["ZipCode"].ToString();
                    lblLunchOption.Text = objReader["LunchOptions"].ToString();
                    

                    if (objReader["AudioAid"].ToString().Equals("True"))
                    {
                        lblAudioAid.Text = "Audio Aid is required";
                    }
                    else
                    {
                        lblAudioAid.Text = "Audio Aid is not required";
                    }
                    if (objReader["VisualAid"].ToString().Equals("True"))
                    {
                        lblVisualAid.Text = "Visual Aid is required";
                    }
                    else
                    {
                        lblVisualAid.Text = "Visual Aid is not required";
                    }

                    if (objReader["MobileAid"].ToString().Equals("True"))
                    {
                        lblMobileAid.Text = "Mobile Aid is required";
                    }
                    else
                    {
                        lblMobileAid.Text = "Mobile Aid is not required";
                    }

                    lblRate.Text = objReader["Rate"].ToString();
                }
            }

            objReader.Close();
            objConnection.Close();

            objReader = null;
            objCommand = null;
            objConnection = null;


        }

      

        protected void bttnUpdate_Click(object sender, EventArgs e)
        {
            Server.Transfer("Update.aspx?ID=" + Request.QueryString["ID"]);
        }

        protected void bttnDelete_Click(object sender, EventArgs e)
        {
            Server.Transfer("Delete.aspx?ID=" + Request.QueryString["ID"]);
        }

        protected void LnkBttn_Click(object sender, EventArgs e)
        {
            Server.Transfer("Dashboard.aspx");
        }
    }
}
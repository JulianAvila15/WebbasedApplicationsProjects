﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace ERM_Web_App.ERMS
{
    public partial class Dashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DisplayDataGrid();
        }

        protected void DisplayDataGrid()
        {
            string strConnection = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"]; ;
            string SQL = "Select [RegistrationID], [FirstName]+' '+[LastName] AS [Name], [LunchOptions], [DateTimeCreated] FROM [Registration_table] WHERE [IsDeleted] = 0 ORDER BY [Name]";

            SqlConnection objConnection = new SqlConnection(strConnection);
            SqlCommand objCommand = new SqlCommand(SQL, objConnection);
            SqlDataAdapter objDataAdapter = new SqlDataAdapter(objCommand);

            DataSet objDataSet = new DataSet();

            objDataAdapter.Fill(objDataSet, "Registrations");


            RegistrationGridView.DataSource = objDataSet;
            RegistrationGridView.DataBind();

            if (objDataSet.Tables[0].Columns.Count == 0)
            {
                lblNoRecordsFound.Visible = true;
                RegistrationGridView.Visible = false;
            }
            else
            {
                lblNoRecordsFound.Visible = false;
                RegistrationGridView.Visible = true;
            }

            objConnection.Close();

            objConnection = null;
            objCommand = null;
            objDataAdapter = null;
            objDataSet = null;

        }

        protected void RegistrationGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            RegistrationGridView.PageIndex = e.NewPageIndex;

            DisplayDataGrid();
        }
    }
}
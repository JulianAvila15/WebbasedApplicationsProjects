﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace ERM_Web_App.ERMS
{
    public partial class Registrationsaspx : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            Page.MaintainScrollPositionOnPostBack = true;
            txtFirstName.Focus();
        }

        protected bool AddRegistration()
        {
            try
            {
            // setup and create the connection to the database
            ADODB.Connection objConnect = new ADODB.Connection();
            ADODB.Recordset objRS = new ADODB.Recordset();

            string strConnection = System.Configuration.ConfigurationManager.AppSettings["ConnectionStringProvider"];
            string SQL = "SELECT * FROM [Registration_table];";

            // open the connection
            objConnect.Open(strConnection);
            objRS.Open(SQL, objConnect, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic);

            // add registration record
            objRS.AddNew();

            objRS.Fields["RegistrationID"].Value = Guid.NewGuid().ToString();

            objRS.Fields["FirstName"].Value = txtFirstName.Text;
            objRS.Fields["LastName"].Value = txtLastName.Text;
            objRS.Fields["BadgeName"].Value = txtBadgeName.Text;

            objRS.Fields["Address1"].Value = txtAddress1.Text;
            objRS.Fields["Address2"].Value = txtAddress2.Text;
            objRS.Fields["City"].Value = txtCity.Text;
            objRS.Fields["State"].Value = txtState.Text;
                objRS.Fields["ZipCode"].Value = txtZip.Text;


                objRS.Fields["LunchOptions"].Value = RadLunchOptions.SelectedValue.ToString();

                if (ChkAudioAid.Checked)
                {
                    objRS.Fields["AudioAid"].Value = 1;
                }
                
                if (ChkVisualAid.Checked)
                {
                    objRS.Fields["VisualAid"].Value = 1;
                }
               
                if (ChkMobileAid.Checked)
                {
                    objRS.Fields["MobileAid"].Value = 1;
                }
                

                if (lstRates.SelectedValue.ToString() == "Member")
               {
                    objRS.Fields["Rate"].Value = 1000;
                }
                else if (lstRates.SelectedValue.ToString() == "Non-Member")
                {
                    objRS.Fields["Rate"].Value = 1300;
               }
                else if (lstRates.SelectedValue.ToString() == "RAUG")
                {
                    objRS.Fields["Rate"].Value = 500;
                }
                

                objRS.Fields["DateTimeCreated"].Value = DateTime.Now;

                objRS.Update();

                objRS.Close();
                objConnect.Close();

                objConnect = null;
                objRS = null;

                return true;

            }
            catch
            {
                return false;
            }
        }

        protected bool SaveRegistration()
        {
            try
            {
                string connectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"]; ;
                string SQL = "INSERT INTO Contacts (FirstName, LastName, DateTimeCreated) VALUES (@FirstName, @LastName, @DateTimeCreated);";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(SQL, connection);

                    command.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                    command.Parameters.AddWithValue("@LastName", txtLastName.Text);
                    command.Parameters.AddWithValue("@DateTimeCreated", DateTime.Now);

                connection.Open();
                command.ExecuteNonQuery();
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        protected void bttnSubmit_Click(object sender, EventArgs e)
        {
            if (IsValid)
            {
                if (AddRegistration())
                {
                    Server.Transfer("ThankYou.aspx");
                }

                else
                {
                    Server.Transfer("Error.aspx");
                }
            }
        }
    }
}
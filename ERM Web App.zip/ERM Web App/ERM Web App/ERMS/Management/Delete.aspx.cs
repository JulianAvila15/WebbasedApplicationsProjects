﻿using ADODB;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.NetworkInformation;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ERM_Web_App.ERMS
{
    public partial class Delete : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ShowMessage(string MessageToDisplay)
        {
            //define name and type of client script

            string csName = "PopupScript";
            Type csType = this.GetType();

            //get client script manager object

            ClientScriptManager cs = Page.ClientScript;

            if(!cs.IsStartupScriptRegistered(csType,csName))
            {
                string csText = "alert('" + MessageToDisplay + "');";
                cs.RegisterStartupScript(csType, csName, csText, true);
            }

        }

        protected bool VerifyForm()
        {

            if(ChkConfirm.Checked)
            {
                return true;
            }
            else
            {
                ShowMessage("Please Confirm your delete action");
                return false;
            }
        }
       protected bool DeleteRegistration(string RecID)
        {

            try
            {
                string connectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"]; ;
                string SQL = "UPDATE Registration_table SET IsDeleted = @IsDeleted, DateTimeDeleted = @DateTimeDeleted WHERE RegistrationID = @RegID";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(SQL, connection);

                    command.Parameters.AddWithValue("@RegID", RecID);
                    command.Parameters.AddWithValue("@IsDeleted", 1);
                    command.Parameters.AddWithValue("@DateTimeDeleted", DateTime.Now);
                    connection.Open();
                    command.ExecuteNonQuery();
                }

                return true;
            }
            catch
            {
                return false;
            }
        }
        protected void BttnDelete_Click(object sender, EventArgs e)
        {
            if (VerifyForm())
            {
                if (DeleteRegistration(Request.QueryString["ID"]))
                {

                    Server.Transfer("Dashboard.aspx");

                }
                else
                {
                    Server.Transfer("Error.aspx");
                }
            }
        }

        protected void lnkCancel_Click(object sender, EventArgs e)
        {
            Server.Transfer("View.aspx?ID=" + Request.QueryString["ID"]);
        }
    }
}
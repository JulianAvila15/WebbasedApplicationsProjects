﻿using ADODB;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ERM_Web_App.ERMS
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            txtUsername.Focus();
        }

        public static string CreateMD5(string input)
        {
            // Use input string to calculate MD5 hash
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                // return Convert.ToHexString(hashBytes); // .NET 5 +

                // Convert the byte array to hexadecimal string prior to .NET 5
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    sb.Append(hashBytes[i].ToString("X2"));
                }
                return sb.ToString();
            }
        }

        protected bool AuthenticateUser(string username, string password)
        {
            bool successful=false;
            //setup and create connection to DB
            try
            {
                
                string strConnection = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
                string SQL = "SELECT [userID] FROM [users_table] WHERE [username]= '" + username + "' AND [password]= '" + password + "';";

                //Response.Write("<p>" + SQL + "<p>");

                SqlConnection objConnection = new SqlConnection(strConnection);

                SqlCommand objCommand = new SqlCommand(SQL);

                objCommand.Connection = objConnection;

                objCommand.Connection.Open();

                SqlDataReader objReader = objCommand.ExecuteReader();

                if (objReader.HasRows)
                {

                    successful = true;
                }
                else
                {
                    successful = false;
                }
               
                objReader.Close();
                objConnection.Close();
                return successful;
            }
            catch
            {
                return successful;
            }
        }

        protected void bttnLogin_Click(object sender, EventArgs e)
        {
            if(IsValid)
            {
                if (AuthenticateUser(txtUsername.Text, CreateMD5(txtPassword.Text)))
                {
                    FormsAuthentication.RedirectFromLoginPage(txtUsername.Text, false);
                }
                else
                {
                   Server.Transfer("/ERMS/Management/Error.aspx");
                }
            }
            else
            {

            }
        }
    }
}
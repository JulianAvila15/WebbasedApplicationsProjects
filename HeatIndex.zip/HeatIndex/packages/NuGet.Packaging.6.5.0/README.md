NuGet's understanding of packages. Reading nuspec, nupkgs and package signing.

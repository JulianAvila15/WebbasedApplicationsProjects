﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CS440WalkToEndAlzheimersAvila.ALZ
{

    public partial class Registration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.MaintainScrollPositionOnPostBack = true;
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

        }

        protected void cmdSubmit_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                Context.Items.Add("WalkLocation",txtWalkLocation.Text);
                Context.Items.Add("Name", txtFirstName.Text + " "+txtLastName.Text);
                Context.Items.Add("TeamName", txtTeamName.Text);
                Context.Items.Add("Role", optIam.Text);
                Context.Items.Add("Goal", txtGoal.Text);
                Context.Items.Add("Donation", ' ' );

                if (RadDonation.SelectedIndex != 3)
                {
                    Context.Items["Donation"] = RadDonation.Text;
                }
                else
                    Context.Items["Donation"] = txtOther.Text;

               Server.Transfer("Confirmation.aspx");
            }
        }

        protected void RadDonation_SelectedIndexChanged(object sender, EventArgs e)
        {
             if (RadDonation.SelectedIndex == 3)
                {
                    txtOther.Visible = true;
                valOtherAmount.Enabled = true;
            }
                else
                {
                    txtOther.Visible = false;
                valOtherAmount.Enabled = false;
                }
            
        }

       
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CS440WalkToEndAlzheimersAvila.ALZ
{
    public partial class Confirmation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                if (Context.Items["WalkLocation"]==null|| Context.Items["Name"] == null||Context.Items["TeamName"] == null||Context.Items["Role"] == null||Context.Items["Goal"] == null||Context.Items["Donation"] == null)
                {
                    Server.Transfer("Registration.aspx");
                }
                lblWalkLocation.Text = Context.Items["WalkLocation"].ToString();
                lblName.Text = Context.Items["Name"].ToString();
                lblTeamName.Text = Context.Items["TeamName"].ToString();
                lblRole.Text = Context.Items["Role"].ToString();
                lblGoal.Text += Context.Items["Goal"].ToString();
                lblDonation.Text += Context.Items["Donation"].ToString();
            }
        
        }

        protected void bttnBack_Click(object sender, EventArgs e)
        {
            Server.Transfer("Registration.aspx");
        }

        protected void bttnConfirm_Click(object sender, EventArgs e)
        {
            Server.Transfer("ThankYou.aspx"); ;
        }
    }
}
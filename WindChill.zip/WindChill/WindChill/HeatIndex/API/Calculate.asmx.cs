﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace WindChill.HeatIndex.API
{
    /// <summary>
    /// Summary description for Calculate
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class Calculate : System.Web.Services.WebService
    {

        [WebMethod]
        public double CalculateHeatIndex (int T, int rh)
        {
            return -43.79 + (2.0401523 * T) + (10.14333127 * rh) - (.22475541 * T * rh) - (6.83783 * (10 ^ -3) * (T ^ 2)) - (5.481717 * (10 ^ -2) * (rh ^ 2))
                    + (1.22874 * (10 ^ -3) * (T ^ 2) * (rh)) + (8.5282 * (10 ^ -4) * T * (rh ^ 2)) - (1.99 * (10 ^ -5) * (T ^ 2) * (rh ^ 2)); ;
        }
    }
}

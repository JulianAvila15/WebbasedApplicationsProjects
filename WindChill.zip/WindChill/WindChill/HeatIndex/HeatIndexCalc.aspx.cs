﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WindChill.HeatIndex
{
    public partial class HeatIndexCalc : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode=UnobtrusiveValidationMode.None;
            txtAirTemperature.Focus();
        }

        protected void cmdCalculate_Click(object sender, EventArgs e)
        {
            if(Page.IsValid)
            {
              HI1.Calculate objHI = new HI1.Calculate();

                int T = Convert.ToInt32(txtAirTemperature.Text);
              int rh = Convert.ToInt32(txtRelativeHumidity.Text);

                double Results = objHI.CalculateHeatIndex(T, rh);
                lblHeatIndex.Text = Results.ToString();
            }   
        }
    }
}